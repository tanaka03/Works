//��������������������������
//light.h
//��������������������������
#ifndef _MYIMGUI_H_
#define _MYIMGUI_H_

//imgui
#define IMGUI_DEFINE_MATH_OPERATORS
#include "imgui.h"
#include "imgui_impl_dx9.h"
#include "imgui_impl_win32.h"
#include "imgui_internal.h"

#include "stage_manager.h"

class CMyImgui
{
public:
	CMyImgui();
	~CMyImgui();

	HRESULT Init();
	void Uninit();
	void Update();
	void Draw();
	bool ImGuiText(bool show_demo_window, bool show_another_window);
	bool isHover() { return m_isHover; }

private:
	void EditStage(std::string stageLabel);
	void ItemList(const std::string& stageLabel);
	void MyTreeNode(std::string label, bool& selected, CStageManager::SObjectData& data, int index);

	void MenuBar();
	void RenderComboBox(std::string label, int& index, std::vector<std::string>& list, std::function<void()> func);
	bool CheckHoverWindow();

	// �J���[�p���b�g
	bool ColorPalette4(const char* label, float col[4]);
	bool ColorPalette(float color[4], float backup_color[4], ImGuiColorEditFlags flags);

	// �^�̕ϊ�
	ImVec4 ColorToImVec4(const D3DXCOLOR& color);
	D3DXCOLOR ImVec4ToColor(const ImVec4& vec);

	std::map<std::string, std::vector<CStageManager::SStageContainer>> m_pStage;
	std::vector<std::string> m_tagList;
	std::string m_nowTag;
	size_t m_selectIndex;
	int m_tagIndex;
	int m_stageIndex;
	int m_modelIndex;
	bool m_isHover;
	bool show_demo_window = true;
	bool show_another_window = false;
};

#endif