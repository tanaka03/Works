#include "stage_grid.h"
#include "application.h"
#include "renderer.h"

namespace
{
	const DWORD FVF_VERTEX_LINE(D3DFVF_XYZ | D3DFVF_DIFFUSE);
	const int lineVtxCnt = 2;
	const int firstEdge = -10000;
}

CStageGrid::CStageGrid() :
	m_stageWidth(10000),
	m_stageHeight(10000), 
	m_gridSize(10),
	m_currentWidth(0),
	m_currentHeight(0),
	m_currentSize(0)
{
	LPDIRECT3DDEVICE9 pDevice = CApplication::GetInstance()->GetRenderer()->GetDevice();

	// ���_�o�b�t�@�̐���
	pDevice->CreateVertexBuffer(sizeof(SGridVertex) * (200 * 200),
		D3DUSAGE_WRITEONLY,
		FVF_VERTEX_LINE,
		D3DPOOL_MANAGED,
		&m_pVtxBuff,
		NULL);

	m_gridVtx.resize(lineVtxCnt + (m_stageWidth - m_gridSize + m_stageHeight / m_gridSize) * lineVtxCnt);
	m_col = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
}

CStageGrid::~CStageGrid()
{
}

void CStageGrid::Draw()
{
	LPDIRECT3DDEVICE9 pDevice = CApplication::GetInstance()->GetRenderer()->GetDevice();	//�f�o�C�X�̎擾

	if (IsGridChanged())
	{
		ReSize();
	}

	// ���C�g�𖳌���
	pDevice->SetRenderState(D3DRS_LIGHTING, FALSE);

	// ���_�o�b�t�@���f�o�C�X�̃f�[�^�X�g���[���ɐݒ�
	pDevice->SetStreamSource(0, m_pVtxBuff, 0, sizeof(SGridVertex));

	pDevice->SetFVF(FVF_VERTEX_LINE);
	pDevice->DrawPrimitiveUP(D3DPT_LINELIST,
		m_index / lineVtxCnt,
		m_gridVtx.data(),
		sizeof(SGridVertex));

	// ���C�g�̐ݒ�����ɖ߂�
	pDevice->SetRenderState(D3DRS_LIGHTING, TRUE);
}

void CStageGrid::ReSize()
{
	m_gridVtx.resize(lineVtxCnt + (m_stageWidth - m_gridSize + m_stageHeight / m_gridSize) * lineVtxCnt);
	int index = 0;

	// X���̃O���b�h��
	for (int i = firstEdge; i <= m_stageWidth; i += m_gridSize)
	{
		D3DXVECTOR3 vtx[2] = { D3DXVECTOR3(i, 0, -m_stageHeight), D3DXVECTOR3(i, 0, m_stageHeight) };
		m_gridVtx[index++] = { vtx[0], m_col };
		m_gridVtx[index++] = { vtx[1], m_col };
	}

	// Z���̃O���b�h��
	for (int i = firstEdge; i <= m_stageHeight; i += m_gridSize)
	{
		D3DXVECTOR3 vtx[2] = { D3DXVECTOR3(-m_stageWidth, 0, i), D3DXVECTOR3(m_stageWidth, 0, i) };
		m_gridVtx[index++] = { vtx[0], m_col };
		m_gridVtx[index++] = { vtx[1], m_col };
	}

	m_currentSize = m_gridSize;
	m_currentWidth = m_stageWidth;
	m_currentHeight = m_stageHeight;
	m_index = index;
}

bool CStageGrid::IsGridChanged()
{
	if (m_gridSize != m_currentSize ||
		m_stageWidth != m_currentWidth ||
		m_stageHeight != m_currentHeight)
	{
		return true;
	}
	return false;
}