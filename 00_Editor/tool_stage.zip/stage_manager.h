//��������������������������
// StageManager.h
//��������������������������
#ifndef _STAGE_MANAGER_H_
#define _STAGE_MANAGER_H_

#include "file.h"

class CStageGrid;
class CStageTexture;

class CStageManager
{
public:
	struct SModelData
	{
		LPD3DXMESH mesh;						// ���b�V�����
		LPD3DXBUFFER buffMat;					// �}�e���A�����
		DWORD dwNum;							// �}�e���A���̌�
		D3DXVECTOR3 maxModel;					// ���f���̍ő�l
		D3DXVECTOR3 minModel;					// ���f���̍ŏ��l
	};

	struct SObjectData
	{
		D3DXVECTOR3 pos;
		D3DXVECTOR3 rot;
		D3DXVECTOR3 scale;
		D3DXMATRIX mtxWorld;
		std::string objectLabel;
		std::string modelLabel;
	};

	struct SStageContainer
	{
		SModelData modelData;
		SObjectData objectData;
	};

	CStageManager();
	~CStageManager();

	void Release();
	void StageDraw(std::string stagePath);
	void Pick();

	void LoadText(std::string path, std::map<std::string, std::vector<SStageContainer>>& data);
	void SaveText(std::map<std::string, std::vector<SStageContainer>>& data);
	void LoadJson(nlohmann::json& list);
	void SaveJson(std::string path, std::map<std::string, std::vector<SStageContainer>>& data);

	void LoadModel(std::string path, SModelData& data);
	void PlaceObject(std::string stagePath, std::string modelPath, SObjectData& data);
	void RemoveObject(std::string stagePath, size_t index);
	void CopyObject(SObjectData& data) { m_copyData = data; }
	SObjectData PasteObject() { return m_copyData; }
	void AddScaleObjectAll(std::string stagePath, D3DXVECTOR3 add);
	bool IsSelect() { return m_isSelected; }

	void SetStageData(std::string label, std::vector<SStageContainer>& info) { m_stageData[label] = info; }
	void SetSelectIndex(size_t index) { m_selectIndex = index, m_isSelected = true; }
	void SetSelectStatus(bool set) { m_isSelected = set; }

	std::vector<SStageContainer> GetStageData(std::string label) { return m_stageData[label]; }
	size_t GetSelectIndex() { return m_selectIndex; }
	CStageGrid* GetGrid() { return m_grid; }

private:
	bool RayIntersect(const D3DXVECTOR3& rayStart, const D3DXVECTOR3& rayDir, const D3DXVECTOR3& minBox, const D3DXVECTOR3& maxBox, float& entry, float& exit);

	std::map<std::string, std::vector<SStageContainer>> m_stageData;
	std::string m_stagePath;
	SObjectData m_copyData;
	CStageTexture* m_pStageTexture;
	CStageGrid* m_grid;
	size_t m_selectIndex;
	bool m_isSelected;
};

#endif
