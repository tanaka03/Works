#include "instancing.h"
#include "application.h"
#include "renderer.h"
#include "shader_manager.h"

namespace
{
	void CopyBuffer(unsigned size, void *src, IDirect3DVertexBuffer9 *buf) 
	{
		void *p = 0;
		buf->Lock(0, 0, &p, 0);
		memcpy(p, src, size);
		buf->Unlock();
	}
}

CInstancing::CInstancing()
{
	std::vector<D3DVERTEXELEMENT9> elements;

	// �X�g���[���ԍ� 0
	elements.push_back({ 0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0});		// ���[�J�����W
	elements.push_back(D3DDECL_END());

	// �X�g���[���ԍ� 1
	elements.push_back({ 1, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 1});		// ���[���h���W
	elements.push_back({ 1, 12, D3DDECLTYPE_D3DCOLOR, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_COLOR, 0 });		// �F
	elements.push_back({ 1, 16, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 });		// UV
	elements.push_back(D3DDECL_END());

	// ���_�錾�I�u�W�F�N�g�̐���
	LPDIRECT3DDEVICE9 pDevice = CApplication::GetInstance()->GetRenderer()->GetDevice();
	pDevice->CreateVertexDeclaration(elements.data(), &m_decl);
}

CInstancing::~CInstancing()
{
}

HRESULT CInstancing::Init()
{
	m_shaderLabel = "TEST";

	LPDIRECT3DDEVICE9 pDevice = CApplication::GetInstance()->GetRenderer()->GetDevice();

	// �o�b�t�@�̐���
	pDevice->CreateVertexBuffer(sizeof(SVertex) * m_numInstance, 0, 0, D3DPOOL_MANAGED, &m_pVtxBuff, 0);
	pDevice->CreateVertexBuffer(sizeof(SInstancingData) * m_numInstance, 0, 0, D3DPOOL_MANAGED, &m_pInstancingBuff, 0);

	CShaderManager* pShader = CApplication::GetInstance()->GetShaderManager();
	if (!m_shaderLabel.empty())
	{
		m_hTechnique = pShader->GetTechniqueCache(m_shaderLabel, "TechShader");
		m_hCameraView = pShader->GetParameterCache(m_shaderLabel, "g_cameraView");
		m_hCameraProjection = pShader->GetParameterCache(m_shaderLabel, "g_cameraProjection");
		m_hMtxWorld = pShader->GetParameterCache(m_shaderLabel, "g_mtxWorld");
	}

	return S_OK;
}

void CInstancing::Uninit()
{
	if(m_decl != nullptr)
	{
		m_decl->Release();
		m_decl = nullptr;
	}

	if (m_pVtxBuff != nullptr)
	{
		m_pVtxBuff->Release();
		m_pVtxBuff = nullptr;
	}

	if (m_pInstancingBuff != nullptr)
	{
		m_pInstancingBuff->Release();
		m_pInstancingBuff = nullptr;
	}
}

void CInstancing::Update()
{

}

void CInstancing::Draw()
{
	LPDIRECT3DDEVICE9 pDevice = CApplication::GetInstance()->GetRenderer()->GetDevice();

	// �C���X�^���X�錾
	pDevice->SetStreamSourceFreq(0, D3DSTREAMSOURCE_INDEXEDDATA | m_numInstance);
	pDevice->SetStreamSourceFreq(1, D3DSTREAMSOURCE_INSTANCEDATA | 1);

	// ���_�錾�I�u�W�F�N�g�̐ݒ�
	pDevice->SetVertexDeclaration(m_decl);

	// �o�b�t�@���f�o�C�X�̃f�[�^�X�g���[���ɐݒ�
	pDevice->SetStreamSource(0, m_pVtxBuff, 0, sizeof(SVertex));
	pDevice->SetStreamSource(1, m_pInstancingBuff, 0, sizeof(SInstancingData));

	// �K�v�ȉ񐔕`����s���H
	//for ()
	//{
	//}

	// �C���X�^���X�̐ݒ�����ɖ߂�
	pDevice->SetStreamSourceFreq(0, 1);
	pDevice->SetStreamSourceFreq(1, 1);
}